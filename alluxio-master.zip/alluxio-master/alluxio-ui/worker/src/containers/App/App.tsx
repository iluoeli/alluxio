/*
 * The Alluxio Open Foundation licenses this work under the Apache License, version 2.0
 * (the "License"). You may not use this work except in compliance with the License, which is
 * available at www.apache.org/licenses/LICENSE-2.0
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied, as more fully set forth in the License.
 *
 * See the NOTICE file distributed with this work for information regarding copyright ownership.
 */

import {AxiosResponse} from 'axios';
import {ConnectedRouter} from 'connected-react-router';
import {History, LocationState} from 'history';
import React from 'react';
import {connect} from 'react-redux';
import {StaticContext} from 'react-router';
import {Redirect, Route, RouteComponentProps, Switch} from 'react-router-dom';
import {Alert} from 'reactstrap';
import {Dispatch} from 'redux';

import {Footer, Header, LoadingMessage} from '@alluxio/common-ui/src/components';
import {triggerRefresh} from '@alluxio/common-ui/src/store/refresh/actions';
import {BlockInfo, Logs, Metrics, Overview} from '..';
import {footerNavigationData, headerNavigationData} from '../../constants';
import {IApplicationState} from '../../store';
import {fetchRequest} from '../../store/init/actions';
import {IInit} from '../../store/init/types';

import './App.css';

interface IPropsFromState {
  init: IInit;
  errors?: AxiosResponse;
  loading: boolean;
  refresh: boolean;
}

interface IPropsFromDispatch {
  fetchRequest: typeof fetchRequest;
  triggerRefresh: typeof triggerRefresh;
}

interface IAppProps {
  history: History<LocationState>;
}

export type AllProps = IPropsFromState & IPropsFromDispatch & IAppProps;

export class App extends React.Component<AllProps> {
  private intervalHandle: any;

  constructor(props: AllProps) {
    super(props);

    this.setAutoRefresh = this.setAutoRefresh.bind(this);
  }

  public componentDidUpdate(prevProps: AllProps) {
    if (this.props.refresh !== prevProps.refresh) {
      this.props.fetchRequest();
    }
  }

  public componentWillMount() {
    this.props.fetchRequest && this.props.fetchRequest();
  }

  public render() {
    const {errors, init, loading, history} = this.props;

    if (errors) {
      return (
        <Alert color="danger">
          Unable to reach the api endpoint for this page.
        </Alert>
      );
    }

    if (!init && loading) {
      return (
        <div className="App">
          <LoadingMessage/>
        </div>
      );
    }

    return (
      <ConnectedRouter history={history}>
        <div className="App h-100">
          <div className="w-100 sticky-top header-wrapper">
            <Header history={history} data={headerNavigationData}
                    callbackParameters={{masterHostname: init.masterHostname, masterPort: init.masterPort}}
                    autoRefreshCallback={this.setAutoRefresh}/>
          </div>
          <div className="w-100 pt-5 mt-3 pb-4 mb-2">
            <Switch>
              <Route exact={true} path="/" render={this.redirectToOverview}/>
              <Route path="/overview" exact={true} component={Overview}/>
              <Route path="/blockInfo" exact={true} component={BlockInfo}/>
              <Route path="/logs" exact={true} render={this.renderView(Logs, {history})}/>
              <Route path="/metrics" exact={true} component={Metrics}/>
              <Route render={this.redirectToOverview}/>
            </Switch>
          </div>
          <div className="w-100 footer-wrapper">
            <Footer data={footerNavigationData}
                    callbackParameters={{masterHostname: init.masterHostname, masterPort: init.masterPort}}/>
          </div>
        </div>
      </ConnectedRouter>
    );
  }

  private renderView(Container: typeof React.Component, props: any) {
    return (routerProps: RouteComponentProps<any, StaticContext, any>) => {
      return (
        <Container {...routerProps} {...props}/>
      );
    }
  }

  private redirectToOverview(routerProps: RouteComponentProps<any, StaticContext, any>) {
    return (
      <Redirect to="/overview"/>
    );
  }

  private setAutoRefresh(shouldAutoRefresh: boolean) {
    const {init} = this.props;
    if (shouldAutoRefresh && !this.intervalHandle) {
      this.intervalHandle = setInterval(this.props.triggerRefresh, init.refreshInterval);
    } else {
      if (this.intervalHandle) {
        clearInterval(this.intervalHandle);
        this.intervalHandle = null;
      }
    }
  }
}

const mapStateToProps = ({init, refresh}: IApplicationState) => ({
  init: init.data,
  errors: init.errors,
  loading: init.loading,
  refresh: refresh.data
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
  fetchRequest: () => dispatch(fetchRequest()),
  triggerRefresh: () => dispatch(triggerRefresh())
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
