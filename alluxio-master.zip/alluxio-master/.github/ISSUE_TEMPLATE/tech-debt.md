---
name: Tech debt
about: Track internal tech debt
title: ''
labels: type-debt
assignees: ''

---

**Summary**
Describe the tech debt

**Urgency**
Explain why it is important to address the tech debt
